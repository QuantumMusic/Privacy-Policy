import components.map.Map;
import components.program.Program;
import components.queue.Queue;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.statement.Statement;
import components.statement.Statement1;
import components.utilities.Tokenizer;

/**
 * Layered implementation of secondary method {@code prettyPrint} for
 * {@code Statement}.
 */
public final class Statement1PrettyPrint1 extends Statement1 {

    /*
     * Private members --------------------------------------------------------
     */

    /**
     * Constructs into the given {@code Statement} the BLOCK statement read from
     * the given input file.
     *
     * @param fileName
     *            the name of the file containing 0 or more statements
     * @param s
     *            the constructed BLOCK statement
     * @replaces s
     * @requires <pre>
     * [fileName is the name of a file containing 0 or more valid BL statements]
     * </pre>
     * @ensures s = [BLOCK statement from file fileName]
     */
    private static void loadStatement(String fileName, Statement s) {
        SimpleReader in = new SimpleReader1L(fileName);
        Queue<String> tokens = Tokenizer.tokens(in);
        s.parseBlock(tokens);
        in.close();
    }

    /**
     * Prints the given number of spaces to the given output stream.
     *
     * @param out
     *            the output stream
     * @param numSpaces
     *            the number of spaces to print
     * @updates out.content
     * @requires out.is_open and spaces >= 0
     * @ensures out.content = #out.content * [numSpaces spaces]
     */
    private static void printSpaces(SimpleWriter out, int numSpaces) {
        for (int i = 0; i < numSpaces; i++) {
            out.print(' ');
        }
    }

    /**
     * Converts c into the corresponding BL condition.
     *
     * @param c
     *            the Condition to convert
     * @return the BL condition corresponding to c
     * @ensures toStringCondition = [BL condition corresponding to c]
     */
    private static String toStringCondition(Condition c) {
        String result;
        switch (c) {
            case NEXT_IS_EMPTY: {
                result = "next-is-empty";
                break;
            }
            case NEXT_IS_NOT_EMPTY: {
                result = "next-is-not-empty";
                break;
            }
            case NEXT_IS_ENEMY: {
                result = "next-is-enemy";
                break;
            }
            case NEXT_IS_NOT_ENEMY: {
                result = "next-is-not-enemy";
                break;
            }
            case NEXT_IS_FRIEND: {
                result = "next-is-friend";
                break;
            }
            case NEXT_IS_NOT_FRIEND: {
                result = "next-is-not-friend";
                break;
            }
            case NEXT_IS_WALL: {
                result = "next-is-wall";
                break;
            }
            case NEXT_IS_NOT_WALL: {
                result = "next-is-not-wall";
                break;
            }
            case RANDOM: {
                result = "random";
                break;
            }
            case TRUE: {
                result = "true";
                break;
            }
            default: {
                // this will never happen...
                result = "";
                break;
            }
        }
        return result;
    }

    /*
     * Constructors -----------------------------------------------------------
     */

    /**
     * No-argument constructor.
     */
    public Statement1PrettyPrint1() {
        super();
    }

    /*
     * Secondary methods ------------------------------------------------------
     */

    @Override
    public void prettyPrint(SimpleWriter out, int offset) {
        assert out != null : "Violation of: out is not null";
        assert out.isOpen() : "Violation of: out.is_open";
        assert offset >= 0 : "Violation of: 0 <= offset";
        switch (this.kind()) {
            case BLOCK: {
                Statement block1 = this.newInstance();
                while (this.lengthOfBlock() > 0) {
                    Statement block2 = this.removeFromBlock(0);
                    block2.prettyPrint(out, offset);
                    block1.addToBlock(block1.lengthOfBlock(), block2);
                }
                this.transferFrom(block1);
                break;
            }

            case IF: {
                Statement ifStatement = this.newInstance();
                Condition condition = this.disassembleIf(ifStatement);
                printSpaces(out, offset);
                out.println("IF " + toStringCondition(condition) + " THEN");
                ifStatement.prettyPrint(out, offset + Program.INDENT_SIZE);
                this.assembleIf(condition, ifStatement);
                printSpaces(out, offset);
                out.println("END IF");
                break;
            }

            case IF_ELSE: {
                Statement ifElse1 = this.newInstance();
                Statement ifElse2 = this.newInstance();
                Condition condition = this.disassembleIfElse(ifElse1, ifElse2);
                printSpaces(out, offset);
                out.println("IF " + toStringCondition(condition) + " THEN");
                ifElse1.prettyPrint(out, offset + Program.INDENT_SIZE);
                printSpaces(out, offset);
                out.println("ELSE");
                ifElse2.prettyPrint(out, offset + Program.INDENT_SIZE);
                this.assembleIfElse(condition, ifElse1, ifElse2);
                printSpaces(out, offset);
                out.println("END IF");
                break;
            }
            case WHILE: {
                Statement whileStatement = this.newInstance();
                Condition condition = this.disassembleWhile(whileStatement);
                printSpaces(out, offset);
                out.println("WHILE " + toStringCondition(condition) + " DO");
                whileStatement.prettyPrint(out, offset + Program.INDENT_SIZE);

                this.assembleWhile(condition, whileStatement);
                printSpaces(out, offset);
                out.println("END WHILE");
                break;
            }
            case CALL: {
                String instr = this.disassembleCall();
                this.assembleCall(instr);
                printSpaces(out, offset);
                out.println(instr);
                break;
            }
            default: {
                // this will never happen...
                break;
            }
        }
    }

    /**
     * Refactors the given {@code Statement} by renaming every occurrence of
     * instruction {@code oldName} to {@code newName}. Every other statement is
     * left unmodified.
     *
     * @param s
     *            the {@code Statement}
     * @param oldName
     *            the name of the instruction to be renamed
     * @param newName
     *            the new name of the renamed instruction
     * @updates s
     * @ensures <pre>
     * {@code s = [#s refactored so that every occurrence of instruction oldName
     *   is replaced by newName]}
     * </pre>
     */
    public static void renameInstruction(Statement s, String oldName,
            String newName) {
        switch (s.kind()) {
            case BLOCK: {
                for (int i = 0; i < s.lengthOfBlock(); i++) {
                    Statement s1 = s.removeFromBlock(i);
                    renameInstruction(s1, oldName, newName);
                    s.addToBlock(i, s1);
                }
                break;
            }
            case IF: {
                Statement s1 = s.newInstance();
                Condition c = s.disassembleIf(s1);
                renameInstruction(s1, oldName, newName);
                s.assembleIf(c, s1);
                break;
            }
            case IF_ELSE: {
                Statement s1 = s.newInstance();
                Statement s2 = s.newInstance();
                Condition c = s.disassembleIfElse(s1, s2);
                renameInstruction(s1, oldName, newName);
                renameInstruction(s2, oldName, newName);
                s.assembleIfElse(c, s1, s2);
                break;
            }
            case WHILE: {
                Statement s1 = s.newInstance();
                Condition c = s.disassembleWhile(s1);
                renameInstruction(s1, oldName, newName);
                s.assembleWhile(c, s1);
                break;
            }
            case CALL: {
                String name = s.disassembleCall();
                if (name.equals(oldName)) {
                    s.assembleCall(newName);
                } else {
                    s.assembleCall(oldName);
                }
                break;
            }
            default: {
                break;
            }
        }
    }

    /**
     * Refactors the given {@code Program} by renaming instruction
     * {@code oldName}, and every call to it, to {@code newName}. Everything
     * else is left unmodified.
     *
     * @param p
     *            the {@code Program}
     * @param oldName
     *            the name of the instruction to be renamed
     * @param newName
     *            the new name of the renamed instruction
     * @updates p
     * @ensures <pre>
     * {@code p = [#p refactored so that instruction oldName and every call
     *   to it are replaced by newName]}
     * </pre>
     */
    public static void renameInstruction2(Program p, String oldName,
            String newName) {

        Map<String, Statement> c = p.newContext();
        Map<String, Statement> ctxt = p.replaceContext(c);

        while (ctxt.size() > 0) {
            Map.Pair<String, Statement> instr = ctxt.removeAny();
            String name = instr.key();
            Statement body = instr.value();

            if (name.equals(oldName)) {
                c.add(newName, body);
            } else {
                c.add(oldName, body);
            }
        }

        Statement b = p.newBody();
        Statement b1 = p.replaceBody(b);

        renameInstruction(b1, oldName, newName);

        /* Reassemble the program */
        p.replaceBody(b1);
        p.replaceContext(c);
    }
    /*
     * Main test method -------------------------------------------------------
     */

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();
        /*
         * Get input file name
         */
        out.print("Enter valid BL statement file name: ");
        String fileName = in.nextLine();
        /*
         * Generate expected output in file "data/expected-output.txt"
         */
        out.println("*** Generating expected output ***");
        Statement s1 = new Statement1();
        loadStatement(fileName, s1);
        SimpleWriter ppOut = new SimpleWriter1L("data/expected-output.txt");
        s1.prettyPrint(ppOut, 2);
        ppOut.close();
        /*
         * Generate actual output in file "data/actual-output.txt"
         */
        out.println("*** Generating actual output ***");
        Statement s2 = new Statement1PrettyPrint1();
        loadStatement(fileName, s2);
        ppOut = new SimpleWriter1L("data/actual-output.txt");
        s2.prettyPrint(ppOut, 2);
        ppOut.close();
        /*
         * Check that prettyPrint restored the value of the statement
         */
        if (s2.equals(s1)) {
            out.println("Statement value restored correctly.");
        } else {
            out.println("Error: statement value was not restored.");
        }

        in.close();
        out.close();
    }

}
