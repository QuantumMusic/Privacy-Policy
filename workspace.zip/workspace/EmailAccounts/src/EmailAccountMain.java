import java.util.Scanner;

/**
 * Simple program to exercise EmailAccount functionality.
 */
public final class EmailAccountMain {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private EmailAccountMain() {
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        System.out.println("Enter your first and last name: ");
        String name = input.nextLine();

        while (name.length() > 0) {
            int indexOfSpace = name.indexOf(" ");
            String firstName = name.substring(0, indexOfSpace);
            String lastName = name.substring(indexOfSpace + 1, name.length());
            EmailAccount account = new EmailAccount1(firstName, lastName);
            System.out.println(account.emailAddress());

            System.out.println("Enter your first and last name: ");
            name = input.nextLine();
        }
        input.close();

    }

}
