import components.sequence.Sequence;
import components.sequence.Sequence1L;

/**
 * Implementation of {@code EmailAccount}.
 *
 * @author Ezekiel Young
 *
 */
public final class EmailAccount1 implements EmailAccount {

    /*
     * Private members --------------------------------------------------------
     */
    /**
     * Representation of {@code this}.
     */
    private String firstName;

    private String lastName;

    private int number = 1;

    static private Sequence<String> nameNumber = new Sequence1L<String>();
    /*
     * Constructor ------------------------------------------------------------
     */

    /**
     * Constructor.
     *
     * @param firstName
     *            the first name
     * @param lastName
     *            the last name
     */
    public EmailAccount1(String firstName, String lastName) {

        for (String eachLastName : nameNumber) {
            if (lastName.toLowerCase().equals(eachLastName.toLowerCase())) {
                this.number++;
            }
        }

        this.firstName = firstName;
        this.lastName = lastName;
        nameNumber.add(0, lastName);
    }

    /*
     * Methods ----------------------------------------------------------------
     */

    @Override
    public String name() {
        String name = this.firstName + " " + this.lastName;
        return name;
    }

    @Override
    public String emailAddress() {
        String emailAddress = this.lastName.toLowerCase() + "." + this.number
                + "@osu.edu";
        return emailAddress;
    }

    @Override
    public String toString() {
        String emailAccount = "Name: " + this.firstName + ", " + this.lastName
                + " Email: " + this.lastName.toLowerCase() + "." + this.number
                + "@osu.edu";
        return emailAccount;
    }

}
