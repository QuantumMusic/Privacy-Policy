import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.naturalnumber.NaturalNumber;

/**
 * JUnit test fixture for {@code NaturalNumber}'s constructors and kernel
 * methods.
 *
 * @author Kesi Maduka, Abdikarim Mohamed
 *
 */
public abstract class NaturalNumberTest {

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @return the new number
     * @ensures constructorTest = 0
     */
    protected abstract NaturalNumber constructorTest();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorTest = i
     */
    protected abstract NaturalNumber constructorTest(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorTest)
     */
    protected abstract NaturalNumber constructorTest(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * implementation under test and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorTest = n
     */
    protected abstract NaturalNumber constructorTest(NaturalNumber n);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @return the new number
     * @ensures constructorRef = 0
     */
    protected abstract NaturalNumber constructorRef();

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param i
     *            {@code int} to initialize from
     * @return the new number
     * @requires i >= 0
     * @ensures constructorRef = i
     */
    protected abstract NaturalNumber constructorRef(int i);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param s
     *            {@code String} to initialize from
     * @return the new number
     * @requires there exists n: NATURAL (s = TO_STRING(n))
     * @ensures s = TO_STRING(constructorRef)
     */
    protected abstract NaturalNumber constructorRef(String s);

    /**
     * Invokes the appropriate {@code NaturalNumber} constructor for the
     * reference implementation and returns the result.
     *
     * @param n
     *            {@code NaturalNumber} to initialize from
     * @return the new number
     * @ensures constructorRef = n
     */
    protected abstract NaturalNumber constructorRef(NaturalNumber n);

    /*
     * Test cases for four constructors
     */

    @Test
    public final void testNoArgumentConstructor() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest();
        NaturalNumber nExpected = this.constructorRef();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the Integer argument constructor low bound.
     */
    @Test
    public final void testIntArgumentConstructorLowBound() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest(0);
        NaturalNumber nExpected = this.constructorRef(0);
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the Integer argument constructor high bound.
     */
    @Test
    public final void testIntArgumentConstructorHighBound() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest(Integer.MAX_VALUE);
        NaturalNumber nExpected = this.constructorRef(Integer.MAX_VALUE);
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the String argument constructor low bound.
     */
    @Test
    public final void testStringArgumentConstructorLowBound() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest("0");
        NaturalNumber nExpected = this.constructorRef("0");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the String argument constructor on the Integer's high bound.
     */
    @Test
    public final void testStringArgumentConstructorIntHighBound() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest("2147483647");
        NaturalNumber nExpected = this.constructorRef("2147483647");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the String argument constructor past the Integer's high bound.
     */
    @Test
    public final void testStringArgumentConstructorPastInttHighBound() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber n = this.constructorTest("21474836472147483647");
        NaturalNumber nExpected = this.constructorRef("21474836472147483647");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the NN argument constructor low bound.
     */
    @Test
    public final void testNNArgumentConstructorLowBound() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber source = this.constructorRef();
        NaturalNumber n = this.constructorTest(source);
        NaturalNumber nExpected = this.constructorRef();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the NN argument constructor on the Integer's high bound.
     */
    @Test
    public final void testNNArgumentConstructorIntHighBound() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber source = this.constructorRef(Integer.MAX_VALUE);
        NaturalNumber n = this.constructorTest(source);
        NaturalNumber nExpected = this.constructorRef(Integer.MAX_VALUE);
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the NN argument constructor past the Integer's high bound.
     */
    @Test
    public final void testNNArgumentConstructorPastInttHighBound() {
        /*
         * Set up variables and call method under test
         */
        NaturalNumber source = this.constructorRef("21474836472147483647");
        NaturalNumber n = this.constructorTest(source);
        NaturalNumber nExpected = this.constructorRef("21474836472147483647");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /*
     * Test cases for kernel method: multiplyBy10
     */

    /**
     * Test the multiplyBy10 method for an empty NN and adding zero.
     */
    @Test
    public final void testMultiplyBy10EmptyAddingZero() {
        /*
         * Set up variables
         */
        NaturalNumber n = this.constructorTest();
        NaturalNumber nExpected = this.constructorRef();
        /*
         * Call method under test
         */
        n.multiplyBy10(0);
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the multiplyBy10 method for an empty NN and adding non-zero.
     */
    @Test
    public final void testMultiplyBy10EmptyAddingNonZero() {
        /*
         * Set up variables
         */
        NaturalNumber n = this.constructorTest();
        NaturalNumber nExpected = this.constructorRef(9);
        /*
         * Call method under test
         */
        n.multiplyBy10(9);
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the multiplyBy10 method for an non-empty NN and adding zero.
     */
    @Test
    public final void testMultiplyBy10NonEmptyAddingZero() {
        /*
         * Set up variables
         */
        NaturalNumber n = this.constructorTest(5);
        NaturalNumber nExpected = this.constructorRef(50);
        /*
         * Call method under test
         */
        n.multiplyBy10(0);
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the multiplyBy10 method for an non-empty NN and adding non-zero.
     */
    @Test
    public final void testMultiplyBy10NonEmptyAddingNonZero() {
        /*
         * Set up variables
         */
        NaturalNumber n = this.constructorTest(5);
        NaturalNumber nExpected = this.constructorRef(57);
        /*
         * Call method under test
         */
        n.multiplyBy10(7);
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the multiplyBy10 method for an non-empty NN past high bound and
     * adding non-zero.
     */
    @Test
    public final void testMultiplyBy10NonEmptyAddingNonZeroHighBound() {
        /*
         * Set up variables
         */
        NaturalNumber n = this.constructorTest("2147483647214748364");
        NaturalNumber nExpected = this.constructorRef("21474836472147483647");
        /*
         * Call method under test
         */
        n.multiplyBy10(7);
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /*
     * Test cases for kernel method: divideBy10
     */

    /**
     * Test the divideBy10 method for a zero NN.
     */
    @Test
    public final void testDivideBy10WhenZero() {
        /*
         * Set up variables
         */
        NaturalNumber n = this.constructorTest();
        NaturalNumber nExpected = this.constructorRef();
        /*
         * Call method under test
         */
        int result = n.divideBy10();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(0, result);
    }

    /**
     * Test the divideBy10 method for a non-zero NN.
     */
    @Test
    public final void testDivideBy10WhenNonZero() {
        /*
         * Set up variables
         */
        NaturalNumber n = this.constructorTest(42);
        NaturalNumber nExpected = this.constructorRef(4);
        /*
         * Call method under test
         */
        int result = n.divideBy10();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(2, result);
    }

    /**
     * Test the divideBy10 method for a non-zero NN past high bound.
     */
    @Test
    public final void testDivideBy10WhenNonZeroPastHighBound() {
        /*
         * Set up variables
         */
        NaturalNumber n = this.constructorTest("21474836472147483647");
        NaturalNumber nExpected = this.constructorRef("2147483647214748364");
        /*
         * Call method under test
         */
        int result = n.divideBy10();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(7, result);
    }

    /*
     * Test cases for kernel method: isZero
     */

    /**
     * Test the isZero method for a zero NN.
     */
    @Test
    public final void testIsZeroWhenZero() {
        /*
         * Set up variables
         */
        NaturalNumber n = this.constructorTest();
        NaturalNumber nExpected = this.constructorRef();
        /*
         * Call method under test
         */
        boolean result = n.isZero();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    /**
     * Test the isZero method for a non-zero NN.
     */
    @Test
    public final void testIsZeroWhenNonZero() {
        /*
         * Set up variables
         */
        NaturalNumber n = this.constructorTest(23);
        NaturalNumber nExpected = this.constructorRef(23);
        /*
         * Call method under test
         */
        boolean result = n.isZero();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /**
     * Test the isZero method for a non-zero NN past high bound.
     */
    @Test
    public final void testIsZeroWhenNonZeroHighBound() {
        /*
         * Set up variables
         */
        NaturalNumber n = this.constructorTest("21474836472147483647");
        NaturalNumber nExpected = this.constructorRef("21474836472147483647");
        /*
         * Call method under test
         */
        boolean result = n.isZero();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

}
