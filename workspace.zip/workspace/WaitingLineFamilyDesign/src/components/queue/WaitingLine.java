package components.queue;

/**
 * {@code WaitingLineKernel} enhanced with secondary methods.
 *
 * @param <T>
 *            type of {@code Queue} entries
 * @mathdefinitions <pre>
 * IS_TOTAL_PREORDER (
 *   r: binary relation on T
 *  ) : boolean is
 *  for all x, y, z: T
 *   ((r(x, y) or r(y, x))  and
 *    (if (r(x, y) and r(y, z)) then r(x, z)))
 *
 * IS_SORTED (
 *   s: string of T,
 *   r: binary relation on T
 *  ) : boolean is
 *  for all x, y: T where (<x, y> is substring of s) (r(x, y))
 * </pre>
 */
public interface WaitingLine<T> extends QueueKernel<T> {
    /**
     * Remove the given {@code customerName} from {@this}.
     *
     * @param customerName
     *            the {@code String} to be removed from {@code this}
     * @updates {@code this}
     * @requires <pre>
     * {@code customerName} is in {@code this}.
     * </pre>
     * @ensures <pre>
     * {@code if #this = a*<customerName>*b then
     * this = a*b where a,b are subsets of #this}
     * </pre>
     */
    void removeCustomer(String customerName);

    /**
     * Reports the name of the customer at the position {@code position} in
     * {@code this}.
     *
     * @param position
     *            the integer position of a customer in line
     * @return the name of the customer at position {@code position}
     * @requires <pre>
     * {@code position} < |this|
     * </pre>
     * @ensures <pre>
     * {@code if this = a*<c>*b and |a| = position then
     * customerAtPosition = c.
     * </pre>
     */
    String customerAtPosition(int position);

    /**
     * Reports the position of given {@code customerName}.
     *
     * @param customerName
     *            the {@code String} to be looked for in {@code this}
     * @return the position of the customer in {@code this}
     * @updates {@code this}
     * @requires <pre>
     * {@code customerName} is in {@code this}.
     * </pre>
     * @ensures <pre>
     * {@code if this = a*<customerName>*b then
     * positionOfCustomer = |a|}
     * </pre>
     */
    int positionOfCustomer(String customerName);
}
