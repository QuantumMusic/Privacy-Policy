package components.waitingline;

import java.util.Iterator;

import components.sequence.Sequence;
import components.sequence.Sequence1L;

/**
 *
 * WaitingLine class extending WaitingLineSecondary.
 *
 * @author Ezekiel
 *
 * @param <T>
 */
public class WaitingLineKernel<T> extends WaitingLineSecondary<T> {

    /*
     * Private members
     */

    /**
     * Concrete represenation of WaitingLine.
     */
    private Queue<T> q;

    /**
     * Creator of initial representation.
     */
    private void createNewRep() {
        this.q = new Queue1L<T>();
    }

    /*
     * Public members
     */

    /**
     * Creates a new representation for {@code this}.
     */
    public WaitingLine() {
        this.createNewRep();
    }

    /*
     * Kernel
     * methods------------------------------------------------------------
     */
    /**
     * Adds {@code customer} to the end of {@code this}.
     *
     * @param customer
     *            the entry to be added
     * @aliases reference {@code customer}
     * @updates this
     * @ensures this = #this * <customer>
     */
    void addCustomer(T customer);

    {
        this.q.enqueue(customer);
    }

    /**
     * Removes and returns the customer at the front of {@code this}.
     *
     * @return the entry removed
     * @updates this
     * @requires this /= <>
     * @ensures #this = <fitstCustomer> * this
     */
    T removeCustomer(T customer){
        T returnCustomer;
        for(int i = 0; i<this.q.size();i++){
            T custo = this.q.dequeue();
            if(customer.equals(custo){
                returnCustomer = custo;
            }
            this.q.enqueue(custo);
        }
            return returnCustomer;
        }

    /**
     * Reports length of {@code this}.
     *
     * @return the length of {@code this}
     * @ensures length = |this|
     */
    int length() {
        return this.q.size();
    }
}
