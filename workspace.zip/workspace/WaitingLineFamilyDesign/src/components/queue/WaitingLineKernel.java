package components.queue;

import components.standard.Standard;

/**
 * First-in-first-out (FIFO) queue kernel component with primary methods. (Note:
 * by package-wide convention, all references are non-null.)
 *
 * @param <T>
 *            type of {@code QueueKernel} entries
 * @mathmodel type QueueKernel is modeled by string of T
 * @initially <pre>
 * default:
 *  ensures
 *   this = <>
 * </pre>
 * @iterator ~this.seen * ~this.unseen = this
 */
public interface WaitingLineKernel<T> extends Standard<Queue<T>>, Iterable<T> {
    /**
     * Adds {@code customer} to the end of {@code this}.
     *
     * @param customer
     *            the entry to be added
     * @aliases reference {@code customer}
     * @updates this
     * @ensures this = #this * <customer>
     */
    void addCustomer(T customer);

    /**
     * Removes and returns the customer at the front of {@code this}.
     *
     * @return the entry removed
     * @updates this
     * @requires this /= <>
     * @ensures #this = <fitstCustomer> * this
     */
    T removeFirstCustomer();

    /**
     * Reports length of {@code this}.
     *
     * @return the length of {@code this}
     * @ensures length = |this|
     */
    int length();
}
