import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Set;

/**
 * Program to copy a text file into another file.
 *
 * @author Ezekiel Young
 *
 */
public final class FilterFileStdJava {

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments: input-file-name output-file-name
     *            filter-file-name
     */
    public static void main(String[] args) throws IOException {
        String inFile = "";
        String outFile = "";
        String filterFile = "";
        String seperators = "";
        inFile = args[0];
        outFile = args[1];
        filterFile = args[2];
        BufferedReader in = null;
        BufferedReader inFilter = null;
        try {
            in = new BufferedReader(new FileReader(inFile));
        } catch (IOException e) {
            System.err.println("Error opening main file");
        }
        try {
            inFilter = new BufferedReader(new FileReader(filterFile));
        } catch (IOException e) {
            System.err.println("Error opening filter file");
        }
        PrintWriter out = null;
        try {
            out = new PrintWriter(new BufferedWriter(new FileWriter(outFile)));
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            String line = inFilter.readLine();
            Set<String> seperators = new HashSet<String>();
            while (line != null) {
                seperators.add(line);
                line = inFilter.readLine();
            }

        } catch (IOException e) {
            System.err.println("Error reading from filter file");
        }
        try {
            String line = in.readLine();
            while (line != null) {
                if(line.contains(seperators)) {
                    ;
                }{
                    for(int i = 0; )
                }
                out.println(line);
                line = in.readLine();
            }

        } catch (IOException e) {
            System.err.println("Error reading from filter file");
        }

        try {
            in.close();
        } catch (IOException e) {
            System.err.println("Error closing main file");
        }
        try {
            inFilter.close();
        } catch (IOException e) {
            System.err.println("Error closing filter file");
        }
        out.close();

    }

}
