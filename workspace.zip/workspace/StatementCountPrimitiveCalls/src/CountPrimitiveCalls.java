import components.statement.Statement;
import components.statement.StatementKernel;
import components.statement.StatementKernel.Condition;

/**
 * Utility class with method to count the number of calls to primitive
 * instructions (move, turnleft, turnright, infect, skip) in a given
 * {@code Statement}.
 *
 * @author Ezekiel Yooung
 *
 */
public final class CountPrimitiveCalls {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private CountPrimitiveCalls() {
    }

    /**
     * Refactors the given {@code Statement} so that every IF_ELSE statement
     * with a negated condition (NEXT_IS_NOT_EMPTY, NEXT_IS_NOT_ENEMY,
     * NEXT_IS_NOT_FRIEND, NEXT_IS_NOT_WALL) is replaced by an equivalent
     * IF_ELSE with the opposite condition and the "then" and "else" BLOCKs
     * switched. Every other statement is left unmodified.
     *
     * @param s
     *            the {@code Statement}
     * @updates s
     * @ensures <pre>
     * s = [#s refactored so that IF_ELSE statements with "not"
     *   conditions are simplified so the "not" is removed]
     * </pre>
     */
    public static void simplifyIfElse(Statement s) {
        switch (s.kind()) {
            case BLOCK: {

                if (s.lengthOfBlock() > 0) {
                    for (int i=0; i<s.lengthOfBlock(); i++) {
                    Statement child = s.removeFromBlock(i);
                    simplifyIfElse(child);
                    s.addToBlock(i,child);
                    }
                break;

            }
            case IF: {
                Statement ifStatement = s.newInstance();
                StatementKernel.Condition c = s.disassembleIf(ifStatement);
                simplifyIfElse(ifStatement);
                s.assembleIf(c,ifStatement);

                break;
            }
            case IF_ELSE: {

                Statement ifStatement = s.newInstance();
                Statement elseStatement = s.newInstance();
                StatementKernel.Condition c = s.disassembleIfElse(ifStatement,elseStatement);
                StatementKernel.Condition newC;
                break;


            }
            case WHILE: {
                Statement child = s.newInstance();
                StatementKernel.Condition c = s.disassembleWhile(child);
                simplifyIfElse(child);
                s.assembleWhile(c, child);
                break;




            }
            case CALL: {
                // nothing to do here...can you explain why?
                break;
            }
            default: {
                // this will never happen...can you explain why?
                break;
            }
        }
    }

    /**
     * Reports the number of calls to primitive instructions (move, turnleft,
     * turnright, infect, skip) in a given {@code Statement}.
     *
     * @param s
     *            the {@code Statement}
     * @return the number of calls to primitive instructions in {@code s}
     * @ensures <pre>
     * countOfPrimitiveCalls =
     *  [number of calls to primitive instructions in s]
     * </pre>
     */
    public static int countOfPrimitiveCalls(Statement s) {
        int count = 0;
        switch (s.kind()) {
            case BLOCK: {
                /*
                 * Add up the number of calls to primitive instructions in each
                 * nested statement in the BLOCK.
                 */
                int place = 0;
                while (place < s.lengthOfBlock()) {
                    Statement statement = s.removeFromBlock(place);
                    count += countOfPrimitiveCalls(statement);
                    s.addToBlock(place, statement);
                    place++;
                }
                break;
            }
            case IF: {
                /*
                 * Find the number of calls to primitive instructions in the
                 * body of the IF.
                 */
                Statement statement = s.newInstance();
                Condition condition = s.disassembleIf(statement);
                count = countOfPrimitiveCalls(statement);
                s.assembleIf(condition, statement);
                break;
            }
            case IF_ELSE: {
                /*
                 * Add up the number of calls to primitive instructions in the
                 * "then" and "else" bodies of the IF_ELSE.
                 */
                Statement firstBlock = s.newInstance();
                Statement secondBlock = s.newInstance();
                Condition condition = s.disassembleIfElse(firstBlock,
                        secondBlock);
                count = countOfPrimitiveCalls(firstBlock)
                        + countOfPrimitiveCalls(secondBlock);
                s.assembleIfElse(condition, firstBlock, secondBlock);
                break;
            }
            case WHILE: {
                /*
                 * Find the number of calls to primitive instructions in the
                 * body of the WHILE.
                 */
                Statement statement = s.newInstance();
                Condition condition = s.disassembleWhile(statement);
                count = countOfPrimitiveCalls(statement);
                s.assembleWhile(condition, statement);
                break;
            }
            case CALL: {
                /*
                 * This is a leaf: the count can only be 1 or 0. Determine
                 * whether this is a call to a primitive instruction or not.
                 */

                String call = s.disassembleCall();
                if (call.equals("turnleft") || call.equals("turnright")
                        || call.equals("skip") || call.equals("infect")
                        || call.equals("move")) {
                    count = 1;
                }
                s.assembleCall(call);
                break;
            }
            default: {
                // this will never happen...can you explain why?
                // all of statements have been covered in previous checks
                break;
            }
        }
        return count;
    }

}
