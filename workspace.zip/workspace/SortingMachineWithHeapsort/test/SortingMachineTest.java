import static org.junit.Assert.assertEquals;

import java.util.Comparator;

import org.junit.Test;

import components.sortingmachine.SortingMachine;

/**
 * JUnit test fixture for {@code SortingMachine<String>}'s constructor and
 * kernel methods.
 *
 * @author Put your name here
 *
 */
public abstract class SortingMachineTest {

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * implementation under test and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorTest = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorTest(
            Comparator<String> order);

    /**
     * Invokes the appropriate {@code SortingMachine} constructor for the
     * reference implementation and returns the result.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @return the new {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures constructorRef = (true, order, {})
     */
    protected abstract SortingMachine<String> constructorRef(
            Comparator<String> order);

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the
     * implementation under test type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures
     *
     *          <pre>
     * createFromArgsTest = (insertionMode, order, [multiSommm                                                                          rtingMachine of entries in args])
     *          </pre>
     */
    private SortingMachine<String> createFromArgsTest(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorTest(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     *
     * Creates and returns a {@code SortingMachine<String>} of the reference
     * implementation type with the given entries and mode.
     *
     * @param order
     *            the {@code Comparator} defining the order for {@code String}
     * @param insertionMode
     *            flag indicating the machine mode
     * @param args
     *            the entries for the {@code SortingMachine}
     * @return the constructed {@code SortingMachine}
     * @requires IS_TOTAL_PREORDER([relation computed by order.compare method])
     * @ensures
     *
     *          <pre>
     * createFromArgsRef = (insertionMode, order, [multiSortingMachine of entries in args])
     *          </pre>
     */
    private SortingMachine<String> createFromArgsRef(Comparator<String> order,
            boolean insertionMode, String... args) {
        SortingMachine<String> sm = this.constructorRef(order);
        for (int i = 0; i < args.length; i++) {
            sm.add(args[i]);
        }
        if (!insertionMode) {
            sm.changeToExtractionMode();
        }
        return sm;
    }

    /**
     * Comparator<String> implementation to be used in all test cases. Compare
     * {@code String}s in lexicographic order.
     */
    private static class StringLT implements Comparator<String> {

        @Override
        public int compare(String s1, String s2) {
            return s1.compareToIgnoreCase(s2);
        }

    }

    /**
     * Comparator instance to be used in all test cases.
     */
    private static final StringLT ORDER = new StringLT();

    // TODO - add test cases for add, changeToExtractionMode, removeFirst,
    // isInInsertionMode, order, and size

    /*
     * Test cases for constructors
     */

    @Test
    public final void testConstructor() {
        /*
         * SortingMachine up variables and call method under test
         */
        SortingMachine<String> n = this.constructorTest(ORDER);
        SortingMachine<String> nExpected = this.constructorRef(ORDER);
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /*
     * Test cases for kernel method: add
     */

    /**
     * Test the add method for an empty SortingMachine.
     */
    @Test
    public final void testAddEmpty() {
        /*
         * SortingMachine up variables
         */
        SortingMachine<String> n = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> nExpected = this.createFromArgsRef(ORDER, true,
                "x");
        /*
         * Call method under test
         */
        n.add("x");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the add method for an non-empty SortingMachine.
     */
    @Test
    public final void testAddNonEmpty() {
        /*
         * SortingMachine up variables
         */
        SortingMachine<String> n = this.createFromArgsTest(ORDER, true, "red",
                "green", "blue");
        SortingMachine<String> nExpected = this.createFromArgsRef(ORDER, true,
                "x", "red", "green", "blue");
        /*
         * Call method under test
         */
        n.add("x");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /*
     * Test cases for kernel method: removeFirst
     */

    /**
     * Test the removeFirst method for a SortingMachine with one element.
     */
    @Test
    public final void testRemoveFirstSingle() {
        /*
         * SortingMachine up variables
         */
        SortingMachine<String> n = this.createFromArgsTest(ORDER, false, "x");
        SortingMachine<String> nExpected = this.createFromArgsRef(ORDER, false);
        /*
         * Call method under test
         */
        String result = n.removeFirst();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals("x", result);
    }

    /**
     * Test the removeFirst method for a SortingMachine with multiple elements.
     */
    @Test
    public final void testRemoveFirstMultiple() {
        /*
         * SortingMachine up variables
         */
        SortingMachine<String> n = this.createFromArgsTest(ORDER, false, "red",
                "green", "blue", "x");
        SortingMachine<String> nExpected = this.createFromArgsRef(ORDER, false,
                "red", "green", "x");
        /*
         * Call method under test
         */
        String result = n.removeFirst();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals("blue", result);
    }

    /*
     * Test cases for kernel method: size
     */

    /**
     * Test the size method for an empty SortingMachine in insertion mode.
     */
    @Test
    public final void testSizeInsertionModeWhenEmpty() {
        /*
         * SortingMachine up variables
         */
        SortingMachine<String> n = this.createFromArgsTest(ORDER, true);
        SortingMachine<String> nExpected = this.createFromArgsRef(ORDER, true);
        /*
         * Call method under test
         */
        int result = n.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(0, result);
    }

    /**
     * Test the size method for a SortingMachine with one item in insertion
     * mode.
     */
    @Test
    public final void testSizInsertionModeeWithOne() {
        /*
         * SortingMachine up variables
         */
        SortingMachine<String> n = this.createFromArgsTest(ORDER, true, "x");
        SortingMachine<String> nExpected = this.createFromArgsRef(ORDER, true,
                "x");
        /*
         * Call method under test
         */
        int result = n.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(1, result);
    }

    /**
     * Test the size method for a SortingMachine with several items in insertion
     * mode.
     */
    @Test
    public final void testSizeInsertionModeWithSeveral() {
        /*
         * SortingMachine up variables
         */
        SortingMachine<String> n = this.createFromArgsTest(ORDER, true, "red",
                "yellow", "green", "blue");
        SortingMachine<String> nExpected = this.createFromArgsRef(ORDER, true,
                "red", "yellow", "green", "blue");
        /*
         * Call method under test
         */
        int result = n.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(4, result);
    }

    /**
     * Test the size method for an empty SortingMachine in extraction mode.
     */
    @Test
    public final void testSizeExtractionModeWhenEmpty() {
        /*
         * SortingMachine up variables
         */
        SortingMachine<String> n = this.createFromArgsTest(ORDER, false);
        SortingMachine<String> nExpected = this.createFromArgsRef(ORDER, false);
        /*
         * Call method under test
         */
        int result = n.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(0, result);
    }

    /**
     * Test the size method for a SortingMachine with one item in extraction
     * mode.
     */
    @Test
    public final void testSizeExtractionModeWithOne() {
        /*
         * SortingMachine up variables
         */
        SortingMachine<String> n = this.createFromArgsTest(ORDER, false, "x");
        SortingMachine<String> nExpected = this.createFromArgsRef(ORDER, false,
                "x");
        /*
         * Call method under test
         */
        int result = n.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(1, result);
    }

    /**
     * Test the size method for a SortingMachine with several items in
     * extraction mode.
     */
    @Test
    public final void testSizeExtractionModeWithSeveral() {
        /*
         * SortingMachine up variables
         */
        SortingMachine<String> n = this.createFromArgsTest(ORDER, false, "red",
                "yellow", "green", "blue");
        SortingMachine<String> nExpected = this.createFromArgsRef(ORDER, false,
                "red", "yellow", "green", "blue");
        /*
         * Call method under test
         */
        int result = n.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(4, result);
    }

}
