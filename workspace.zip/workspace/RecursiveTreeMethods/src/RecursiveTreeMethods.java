import components.tree.Tree;

/**
 * Put a short phrase describing the program here.
 *
 * @author Put your name here
 *
 */
public final class RecursiveTreeMethods {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private RecursiveTreeMethods() {
    }

    /**
     * Returns the size of the given {@code Tree<T>}.
     *
     * @param <T>
     *            the type of the {@code Tree} node labels
     * @param t
     *            the {@code Tree} whose size to return
     * @return the size of the given {@code Tree}
     * @ensures size = |t|
     */
    public static <T> int recursiveSize(Tree<T> t) {
        int size = 0;
        if (t.height() > 0) {
            for (int i = 0; i < t.numberOfSubtrees(); i++) {
                Tree<T> child = t.removeSubtree(i);
                size += 1 + size(child);
                t.addSubtree(i, child);
            }
        }
        return size;
    }

    public static <T> int size(Tree<T> t) {
        int size = 0;
        for (T elements : t) {
            size++;
        }
        return size;
    }

    /**
     * Returns the height of the given {@code Tree<T>}.
     *
     * @param <T>
     *            the type of the {@code Tree} node labels
     * @param t
     *            the {@code Tree} whose height to return
     * @return the height of the given {@code Tree}
     * @ensures height = ht(t)
     */
    public static <T> int height(Tree<T> t) {
        int height = 0;
        if (t.size() > 0) {
            for (int i = 0; i < t.numberOfSubtrees(); i++) {
                Tree<T> child = t.removeSubtree(1);
                height += height(child) + 1;
                t.addSubtree(i, child);
            }
        }
        return height;
    }

    /**
     * Returns the largest integer in the given {@code Tree<Integer>}.
     *
     * @param t
     *            the {@code Tree<Integer>} whose largest integer to return
     * @return the largest integer in the given {@code Tree<Integer>}
     * @requires |t| > 0
     * @ensures <pre>
     * max is in labels(t)  and
     * for all i: integer where (i is in labels(t)) (i <= max)
     * </pre>
     */
    public static int max(Tree<Integer> t) {
        int largest = 0;
        if (t.height() != 0) {
            for (int i = 0; i < t.numberOfSubtrees(); i++) {
                Tree<Integer> child = t.removeSubtree(i);
                int temp = child.root();
                largest = max(child);
                if (temp > largest) {
                    largest = temp;
                }
                t.addSubtree(i, child);
            }
        }
        return largest;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        /*
         * Put your main program code here
         */
    }

}
