import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import components.map.Map;
import components.map.Map.Pair;

/**
 * JUnit test fixture for {@code Map<String, String>}'s constructor and kernel
 * methods.
 *
 * @author Kesi Maduka, Abdikarim Mohamed, Ezekiel Young
 *
 */
public abstract class MapTest {

    /**
     * Invokes the appropriate {@code Map} constructor for the implementation
     * under test and returns the result.
     *
     * @return the new map
     * @ensures constructorTest = {}
     */
    protected abstract Map<String, String> constructorTest();

    /**
     * Invokes the appropriate {@code Map} constructor for the reference
     * implementation and returns the result.
     *
     * @return the new map
     * @ensures constructorRef = {}
     */
    protected abstract Map<String, String> constructorRef();

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the implementation
     * under test type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires
     *
     *           <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     *           </pre>
     *
     * @ensures createFromArgsTest = [pairs in args]
     */
    private Map<String, String> createFromArgsTest(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorTest();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /**
     *
     * Creates and returns a {@code Map<String, String>} of the reference
     * implementation type with the given entries.
     *
     * @param args
     *            the (key, value) pairs for the map
     * @return the constructed map
     * @requires
     *
     *           <pre>
     * [args.length is even]  and
     * [the 'key' entries in args are unique]
     *           </pre>
     *
     * @ensures createFromArgsRef = [pairs in args]
     */
    private Map<String, String> createFromArgsRef(String... args) {
        assert args.length % 2 == 0 : "Violation of: args.length is even";
        Map<String, String> map = this.constructorRef();
        for (int i = 0; i < args.length; i += 2) {
            assert !map.hasKey(args[i]) : ""
                    + "Violation of: the 'key' entries in args are unique";
            map.add(args[i], args[i + 1]);
        }
        return map;
    }

    /*
     * Test cases for constructors
     */

    /**
     * Test for constructor.
     */
    @Test
    public final void testConstructor() {
        /*
         * Set up variables and call method under test
         */
        Map<String, String> n = this.constructorTest();
        Map<String, String> nExpected = this.constructorRef();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /*
     * Test cases for kernel method: add
     */

    /**
     * Test the add method for an empty Set.
     */
    @Test
    public final void testAddEmpty() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest();
        Map<String, String> nExpected = this.createFromArgsRef("x", "1");
        /*
         * Call method under test
         */
        n.add("x", "1");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /**
     * Test the add method for an non-empty Set.
     */
    @Test
    public final void testAddNonEmptyAdd() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "height", "50", "width", "50", "depth", "42", "color",
                "purple");
        Map<String, String> nExpected = this.createFromArgsRef("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "height", "50", "mass", "500k", "width", "50", "depth",
                "42", "color", "purple");
        /*
         * Call method under test
         */
        n.add("mass", "500k");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
    }

    /*
     * Test cases for kernel method: remove
     */

    /**
     * Test the remove method for an non-empty Set with one element.
     */
    @Test
    public final void testRemoveNonEmptySingle() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest("x", "1");
        Map<String, String> nExpected = this.createFromArgsRef();
        /*
         * Call method under test
         */
        Pair<String, String> result = n.remove("x");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals("x", result.key());
        assertEquals("1", result.value());
    }

    /**
     * Test the remove method for an non-empty Set with multiple elements.
     */
    @Test
    public final void testRemoveNonEmptyMultiple() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "height", "50", "mass", "500k", "width", "50", "depth",
                "42", "color", "purple");
        Map<String, String> nExpected = this.createFromArgsRef("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "mass", "500k", "width", "50", "depth", "42", "color",
                "purple");
        /*
         * Call method under test
         */
        Pair<String, String> result = n.remove("height");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals("height", result.key());
        assertEquals("50", result.value());
    }

    /*
     * Test cases for kernel method: removeAny
     */

    /**
     * Test the remove method for an non-empty Set with one element.
     */
    @Test
    public final void testRemoveAnyNonEmptySingle() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest("x", "1");
        Map<String, String> nExpected = this.createFromArgsRef();
        /*
         * Call method under test
         */
        Pair<String, String> result = n.removeAny();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals("x", result.key());
        assertEquals("1", result.value());
    }

    /**
     * Test the removeAny method for an non-empty Set with multiple elements.
     */
    @Test
    public final void testRemoveAnyNonEmptyMultiple() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "height", "50", "mass", "500k", "width", "50", "depth",
                "42", "color", "purple");
        Map<String, String> n2 = this.createFromArgsRef("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "height", "50", "mass", "500k", "width", "50", "depth",
                "42", "color", "purple");
        /*
         * Call method under test
         */
        Pair<String, String> result = n.removeAny();
        /*
         * Assert that values of variables match expectations
         */
        assertTrue(n2.hasKey(result.key()));
        Pair<String, String> result2 = n2.remove(result.key());

        assertEquals(n2, n);
        assertEquals(result2, result);
    }

    /*
     * Test cases for kernel method: value
     */

    /**
     * Test the value method for an non-empty Set with one element.
     */
    @Test
    public final void testValueNonEmptySingle() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest("x", "1");
        Map<String, String> nExpected = this.createFromArgsRef("x", "1");
        /*
         * Call method under test
         */
        String result = n.value("x");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals("1", result);
    }

    /**
     * Test the value method for an non-empty Set with multiple elements.
     */
    @Test
    public final void testValueNonEmptyMultiple() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "height", "50", "mass", "500k", "width", "50", "depth",
                "42", "color", "purple");
        Map<String, String> nExpected = this.createFromArgsRef("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "height", "50", "mass", "500k", "width", "50", "depth",
                "42", "color", "purple");
        /*
         * Call method under test
         */
        String result = n.value("color");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals("purple", result);
    }

    /*
     * Test cases for kernel method: hasKey
     */

    /**
     * Test the hasKey method for an empty set.
     */
    @Test
    public final void testHasKeyWhenEmpty() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest();
        Map<String, String> nExpected = this.createFromArgsRef();
        /*
         * Call method under test
         */
        boolean result = n.hasKey("x");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /**
     * Test the hasKey method for a set with one item when true.
     */
    @Test
    public final void testHasKeyWithOneTrue() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest("x", "1");
        Map<String, String> nExpected = this.createFromArgsRef("x", "1");
        /*
         * Call method under test
         */
        boolean result = n.hasKey("x");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    /**
     * Test the hasKey method for a set with one item when false.
     */
    @Test
    public final void testHasKeyWithOneFalse() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest("x", "1");
        Map<String, String> nExpected = this.createFromArgsRef("x", "1");
        /*
         * Call method under test
         */
        boolean result = n.hasKey("y");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /**
     * Test the hasKey method for a set with several items when true.
     */
    @Test
    public final void testHasKeyWithSeveralTrue() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "height", "50", "mass", "500k", "width", "50", "depth",
                "42", "color", "purple");
        Map<String, String> nExpected = this.createFromArgsRef("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "height", "50", "mass", "500k", "width", "50", "depth",
                "42", "color", "purple");
        /*
         * Call method under test
         */
        boolean result = n.hasKey("width");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(true, result);
    }

    /**
     * Test the hasKey method for a set with several items when false.
     */
    @Test
    public final void testHasKeyWithSeveralFalse() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "height", "50", "mass", "500k", "width", "50", "depth",
                "42", "color", "purple");
        Map<String, String> nExpected = this.createFromArgsRef("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "height", "50", "mass", "500k", "width", "50", "depth",
                "42", "color", "purple");
        /*
         * Call method under test
         */
        boolean result = n.hasKey("x");
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(false, result);
    }

    /*
     * Test cases for kernel method: size
     */

    /**
     * Test the size method for an empty set.
     */
    @Test
    public final void testSizeWhenEmpty() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest();
        Map<String, String> nExpected = this.createFromArgsRef();
        /*
         * Call method under test
         */
        int result = n.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(0, result);
    }

    /**
     * Test the size method for a set with one item.
     */
    @Test
    public final void testSizeWithOne() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest("x", "1");
        Map<String, String> nExpected = this.createFromArgsRef("x", "1");
        /*
         * Call method under test
         */
        int result = n.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(1, result);
    }

    /**
     * Test the size method for a set with several items.
     */
    @Test
    public final void testSizeWithSeveral() {
        /*
         * Set up variables
         */
        Map<String, String> n = this.createFromArgsTest("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "height", "50", "mass", "500k", "width", "50", "depth",
                "42", "color", "purple");
        Map<String, String> nExpected = this.createFromArgsRef("radius", "2",
                "diameter", "4", "density", "33", "alpha", "0.5", "gamma",
                "0.7", "height", "50", "mass", "500k", "width", "50", "depth",
                "42", "color", "purple");
        /*
         * Call method under test
         */
        int result = n.size();
        /*
         * Assert that values of variables match expectations
         */
        assertEquals(nExpected, n);
        assertEquals(10, result);
    }
}
